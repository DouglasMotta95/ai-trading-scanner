import { rsi, macd } from './indicators.js';

const finite = v => v == null || v === '' ? null : Number.isFinite(Number(v)) ? Number(v) : null;
const clamp = (v, min = 0, max = 100) => Math.max(min, Math.min(max, Number(v) || 0));
const avg = a => a.length ? a.reduce((s, v) => s + v, 0) / a.length : 0;
const sum = a => a.reduce((s, v) => s + v, 0);

export const INDICATOR_SCORE_WEIGHTS = Object.freeze({
  rsiFavor: 8,
  macdFavor: 10,
  macdAgainst: -10,
  ema: 0,
  bollinger: 0
});

export const ANALYST_THRESHOLDS = Object.freeze({
  minimumClosedCandles: 2,
  preferredClosedCandles: 3,
  minimumPatternRows: 3,
  possibleScore: 44,
  confirmScore: 58,
  candleStrength: 62,
  rejectionStrength: 50
});

function shape(c) {
  const open = finite(c?.open), high = finite(c?.high), low = finite(c?.low), close = finite(c?.close);
  if ([open, high, low, close].some(v => v == null)) return null;
  const range = Math.max(1e-12, high - low);
  const body = Math.abs(close - open);
  const upper = Math.max(0, high - Math.max(open, close));
  const lower = Math.max(0, Math.min(open, close) - low);
  const direction = close > open ? 'BUY' : close < open ? 'SELL' : null;
  const bodyRatio = body / range;
  const upperRatio = upper / range;
  const lowerRatio = lower / range;
  const closeFromLow = clamp(((close - low) / range) * 100);
  const closeFromHigh = clamp(((high - close) / range) * 100);
  const buyPressure = clamp(closeFromLow * .6 + (direction === 'BUY' ? bodyRatio * 100 * .4 : 0));
  const sellPressure = clamp(closeFromHigh * .6 + (direction === 'SELL' ? bodyRatio * 100 * .4 : 0));
  return {
    open, high, low, close, range, body, bodyRatio, upperRatio, lowerRatio, direction,
    strength: clamp(bodyRatio * 100),
    buyPressure,
    sellPressure
  };
}

function momentum(rows = []) {
  if (rows.length < 2) return { direction: null, score: 0, net: 0 };
  const deltas = rows.slice(1).map((row, index) => row.close - rows[index].close);
  const net = sum(deltas);
  const activity = sum(deltas.map(Math.abs));
  const avgRange = Math.max(1e-12, avg(rows.map(row => row.range)));
  const directionalConsistency = activity > 0 ? Math.abs(net) / activity : 0;
  const displacement = Math.min(1, Math.abs(net) / (avgRange * Math.max(1, deltas.length)));
  return {
    direction: net > 0 ? 'BUY' : net < 0 ? 'SELL' : null,
    score: clamp((directionalConsistency * .65 + displacement * .35) * 100),
    net
  };
}

function indicatorReinforcement(candles = [], direction = null) {
  const closes = (Array.isArray(candles) ? candles : [])
    .map(c => finite(c?.close))
    .filter(v => v != null);
  const rsiValue = rsi(closes);
  const macdValue = macd(closes);
  let rsiEffect = 0;
  let macdEffect = 0;
  const reasons = [];

  if (direction === 'BUY' && rsiValue != null && rsiValue > 50) rsiEffect = INDICATOR_SCORE_WEIGHTS.rsiFavor;
  if (direction === 'SELL' && rsiValue != null && rsiValue < 50) rsiEffect = INDICATOR_SCORE_WEIGHTS.rsiFavor;
  if (rsiEffect) reasons.push(`RSI ${rsiValue.toFixed(1)} reforça ${direction} (+${rsiEffect})`);

  const histogram = finite(macdValue?.histogram);
  if (direction && histogram != null && histogram !== 0) {
    const favorsDirection = direction === 'BUY' ? histogram > 0 : histogram < 0;
    macdEffect = favorsDirection ? INDICATOR_SCORE_WEIGHTS.macdFavor : INDICATOR_SCORE_WEIGHTS.macdAgainst;
    reasons.push(`MACD ${favorsDirection ? 'a favor' : 'contra'} ${direction} (${macdEffect > 0 ? '+' : ''}${macdEffect})`);
  }

  return {
    weights: { ...INDICATOR_SCORE_WEIGHTS },
    rsi: { value: rsiValue, effect: rsiEffect },
    macd: { ...(macdValue || { macd: null, signal: null, histogram: null }), effect: macdEffect },
    ema: { effect: INDICATOR_SCORE_WEIGHTS.ema },
    bollinger: { effect: INDICATOR_SCORE_WEIGHTS.bollinger },
    adjustment: rsiEffect + macdEffect,
    reasons
  };
}

function analystMetrics(rows = []) {
  const window = rows.slice(-5);
  const last = window[window.length - 1] || null;
  const previous = window.slice(0, -1);
  const buyPower = clamp(avg(window.map(row => row.buyPressure)));
  const sellPower = clamp(avg(window.map(row => row.sellPressure)));
  const momentumValue = momentum(window);
  const currentStrength = clamp(last?.strength || 0);
  const rejectionBuy = clamp((last?.lowerRatio || 0) * 100);
  const rejectionSell = clamp((last?.upperRatio || 0) * 100);
  const rejectionDirection = rejectionBuy >= ANALYST_THRESHOLDS.rejectionStrength && last?.close > last?.open
    ? 'BUY'
    : rejectionSell >= ANALYST_THRESHOLDS.rejectionStrength && last?.close < last?.open
      ? 'SELL'
      : null;
  const rejectionStrength = rejectionDirection === 'BUY' ? rejectionBuy : rejectionDirection === 'SELL' ? rejectionSell : Math.max(rejectionBuy, rejectionSell);
  const previousBody = avg(previous.map(row => row.bodyRatio));
  const bodyLoss = previousBody > 0 ? clamp(((previousBody - (last?.bodyRatio || 0)) / previousBody) * 100) : 0;
  const oppositeWick = last?.direction === 'BUY' ? rejectionSell : last?.direction === 'SELL' ? rejectionBuy : Math.max(rejectionBuy, rejectionSell);
  const lossOfStrength = clamp(bodyLoss * .7 + oppositeWick * .3);

  return {
    buyPower,
    sellPower,
    currentStrength,
    rejectionDirection,
    rejectionStrength,
    rejectionBuy,
    rejectionSell,
    momentumDirection: momentumValue.direction,
    momentumScore: momentumValue.score,
    lossOfStrength
  };
}

export function recentPriceAction(candles = []) {
  const rows = (Array.isArray(candles) ? candles : []).map(shape).filter(Boolean).slice(-10);
  if (rows.length < ANALYST_THRESHOLDS.minimumPatternRows) {
    return {
      ready: false,
      required: ANALYST_THRESHOLDS.minimumPatternRows,
      count: rows.length,
      direction: null,
      score: 0,
      opinion: 'Montando padrão com as velas recentes e a vela atual.',
      breakout: null,
      lateral: false,
      doji: false,
      rejection: null,
      aligned: 0,
      metrics: analystMetrics(rows)
    };
  }

  const last = rows[rows.length - 1];
  const prev = rows.slice(0, -1);
  const support = Math.min(...rows.map(x => x.low));
  const resistance = Math.max(...rows.map(x => x.high));
  const up = rows.filter(x => x.direction === 'BUY').length;
  const down = rows.filter(x => x.direction === 'SELL').length;
  const aligned = Math.max(up, down);
  const agreement = aligned / rows.length;
  const majority = up === down ? null : up > down ? 'BUY' : 'SELL';
  const avgBody = avg(rows.map(x => x.bodyRatio));
  const rangeSpan = resistance - support;
  const tiny = rows.filter(x => x.bodyRatio < .2).length;
  const lateral = rangeSpan > 0 && Math.abs(last.close - rows[0].open) / rangeSpan < .2 && avgBody < .38;
  const doji = last.bodyRatio < .12 && last.upperRatio > .28 && last.lowerRatio > .28;
  const force = last.bodyRatio >= ANALYST_THRESHOLDS.candleStrength / 100;
  const prevHigh = Math.max(...prev.slice(-4).map(x => x.high));
  const prevLow = Math.min(...prev.slice(-4).map(x => x.low));
  const breakout = last.close > prevHigh ? 'BUY' : last.close < prevLow ? 'SELL' : null;
  const rejection = last.lowerRatio >= ANALYST_THRESHOLDS.rejectionStrength / 100 && last.close > last.open
    ? 'BUY'
    : last.upperRatio >= ANALYST_THRESHOLDS.rejectionStrength / 100 && last.close < last.open
      ? 'SELL'
      : null;
  const metrics = analystMetrics(rows);

  let buy = 0, sell = 0;
  const reasons = [];
  const trendPoints = agreement >= .7 ? 34 : agreement >= .6 ? 26 : 14;
  if (majority === 'BUY') { buy += trendPoints; reasons.push(`${up} de ${rows.length} velas favorecem alta`); }
  if (majority === 'SELL') { sell += trendPoints; reasons.push(`${down} de ${rows.length} velas favorecem baixa`); }
  if (force && last.direction === 'BUY') { buy += 24; reasons.push('Vela atual mostra força compradora'); }
  if (force && last.direction === 'SELL') { sell += 24; reasons.push('Vela atual mostra força vendedora'); }
  if (breakout === 'BUY') { buy += 28; reasons.push('Preço rompe a máxima recente'); }
  if (breakout === 'SELL') { sell += 28; reasons.push('Preço rompe a mínima recente'); }
  if (rejection === 'BUY') { buy += 28; reasons.push('Rejeição compradora confirmada na formação atual'); }
  if (rejection === 'SELL') { sell += 28; reasons.push('Rejeição vendedora confirmada na formação atual'); }

  const powerDiff = metrics.buyPower - metrics.sellPower;
  if (powerDiff >= 12) reasons.push(`Poder comprador ${Math.round(metrics.buyPower)}% domina o vendedor`);
  if (powerDiff <= -12) reasons.push(`Poder vendedor ${Math.round(metrics.sellPower)}% domina o comprador`);
  if (metrics.momentumDirection === 'BUY' && metrics.momentumScore >= 45) reasons.push('Momentum recente favorece alta');
  if (metrics.momentumDirection === 'SELL' && metrics.momentumScore >= 45) reasons.push('Momentum recente favorece baixa');

  let direction = buy === sell ? majority : buy > sell ? 'BUY' : 'SELL';
  let score = Math.max(buy, sell);
  if (agreement >= .6) score += 10;
  if (avgBody >= .48) score += 8;

  const continuationDirection = direction && last.direction === direction && metrics.momentumDirection === direction ? direction : null;
  const continuationScore = continuationDirection
    ? clamp(agreement * 45 + metrics.momentumScore * .3 + metrics.currentStrength * .25)
    : 0;
  if (continuationDirection && continuationScore >= 60) {
    reasons.push(`Continuação ${direction === 'BUY' ? 'compradora' : 'vendedora'} consistente`);
  }

  if (metrics.lossOfStrength >= 72 && !breakout && !rejection) {
    reasons.push('A vela atual perdeu força; confirmação exige continuidade');
  }
  if (lateral) { score = Math.min(score, 54); direction = null; reasons.push('Mercado lateral nas últimas velas'); }
  if (doji && !rejection) { score = Math.min(score, 48); direction = null; reasons.push('Doji sem confirmação'); }
  if (tiny >= Math.ceil(rows.length * .6) && agreement < .75) { score = Math.min(score, 56); direction = null; reasons.push('Compressão: aguardando rompimento'); }
  score = clamp(score);

  const opinion = !direction
    ? (reasons[reasons.length - 1] || 'Sem direção clara no padrão atual.')
    : reasons[0] || `Movimento recente favorece ${direction}.`;

  return {
    ready: true,
    required: ANALYST_THRESHOLDS.minimumPatternRows,
    count: rows.length,
    direction,
    score,
    opinion,
    breakout,
    lateral,
    doji,
    rejection,
    aligned,
    agreement,
    up,
    down,
    force,
    continuationDirection,
    continuationScore,
    metrics,
    reasons
  };
}

export function analyzeCandles(candles = [], indicatorCandles = candles) {
  const rows = (Array.isArray(candles) ? candles : []).filter(c => [c?.open, c?.high, c?.low, c?.close].every(v => finite(v) != null));
  const indicatorRows = (Array.isArray(indicatorCandles) ? indicatorCandles : []).filter(c => finite(c?.close) != null);
  const recent = recentPriceAction(rows);
  if (!recent.ready) {
    return {
      state: 'WAIT',
      score: 0,
      baseScore: 0,
      direction: null,
      reasons: [recent.opinion],
      recent,
      indicators: indicatorReinforcement(indicatorRows, null),
      analytics: recent.metrics || {}
    };
  }
  if (!recent.direction) {
    return {
      state: 'NO_TRADE',
      score: recent.score,
      baseScore: recent.score,
      direction: null,
      reasons: recent.reasons,
      recent,
      indicators: indicatorReinforcement(indicatorRows, null),
      analytics: recent.metrics || {}
    };
  }

  const indicators = indicatorReinforcement(indicatorRows, recent.direction);
  const score = clamp(recent.score + indicators.adjustment);
  return {
    state: score >= ANALYST_THRESHOLDS.possibleScore ? 'WATCH' : 'WAIT',
    score,
    baseScore: recent.score,
    direction: recent.direction,
    reasons: [...recent.reasons, ...indicators.reasons],
    recent,
    indicators,
    analytics: {
      ...(recent.metrics || {}),
      continuationDirection: recent.continuationDirection || null,
      continuationScore: Number(recent.continuationScore || 0),
      rsi: indicators.rsi?.value ?? null,
      macdHistogram: indicators.macd?.histogram ?? null
    }
  };
}
